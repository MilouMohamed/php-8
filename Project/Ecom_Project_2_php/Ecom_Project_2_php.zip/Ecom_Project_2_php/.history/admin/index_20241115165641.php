<?php 
include "init.php";
include($temp."headerAdmin.php");
include "./"
?>

<h1>Page Admine ICI</h1>


<?php include($temp."footerAdmin.php"); ?>