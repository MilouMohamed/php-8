<?php


$cdn="Mysql:host=localhost,dbname=ecom_php_2";
$user="root";
$pass="";


