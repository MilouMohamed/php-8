<?php 
include "init.php";
include($temp."headerAdmin.php");
include "./includes/lang/en.php";
?>

<h1>
    <?= lang("MESSAGE")." ".  ?>
</h1>


<?php include($temp."footerAdmin.php"); ?>