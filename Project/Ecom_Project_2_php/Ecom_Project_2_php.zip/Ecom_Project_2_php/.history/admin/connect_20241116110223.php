<?php


$cdn="Mysql:host=localhost"


