<?php 

include_once("./includes/templates/")
?>