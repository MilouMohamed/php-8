<?php 
include "init.php";
include($temp."headerAdmin.php");
include "./includes/lang/"
?>

<h1>Page Admine ICI</h1>


<?php include($temp."footerAdmin.php"); ?>