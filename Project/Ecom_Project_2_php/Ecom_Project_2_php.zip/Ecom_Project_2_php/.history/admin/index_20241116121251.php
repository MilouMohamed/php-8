<?php 
include "init.php";
include($temp."headerAdmin.php");
include "./includes/lang/en.php";
?>

<form action="" method="post">
<input type="text" name="UserName" placeholder="Nom 1">
<input type="text" name="Password" placeholder="0000">
<input type="submit" value="Se ">

</form>



<h1>
    <?= lang("MESSAGE")." ".lang("ADMIN")  ?>
</h1>


<?php include($temp."footerAdmin.php"); ?>