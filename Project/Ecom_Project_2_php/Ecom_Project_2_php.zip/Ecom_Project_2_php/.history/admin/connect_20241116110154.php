<?php


$cdn="Mysql:"


