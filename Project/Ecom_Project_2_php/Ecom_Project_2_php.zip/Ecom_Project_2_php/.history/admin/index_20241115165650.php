<?php 
include "init.php";
include($temp."headerAdmin.php");
include "./includes"
?>

<h1>Page Admine ICI</h1>


<?php include($temp."footerAdmin.php"); ?>