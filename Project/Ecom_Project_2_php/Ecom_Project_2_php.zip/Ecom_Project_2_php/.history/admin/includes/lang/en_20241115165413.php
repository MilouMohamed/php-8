<?php


function lang(){



    
}

