<?php


function lang($phrase){

static $lg=array(


    
)


}

