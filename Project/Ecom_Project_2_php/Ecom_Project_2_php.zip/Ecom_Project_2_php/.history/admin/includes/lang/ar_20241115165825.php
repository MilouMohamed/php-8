<?php


function lang($phrase){

static $lg=array(

    // HOME PAGE
    "MESSAGE"=>"mar",
    "ADMIN"=>"Administrator", 

);
return $lg[$phrase];

}

