<?php


function lang()

