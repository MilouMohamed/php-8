<?php


function lang($phrase){

static $lg=array(

    // HOME PAGE
    "MESSAGE"=>"mar7aban",
    "ADMIN"=>"Masool", 

);
return $lg[$phrase];

}

