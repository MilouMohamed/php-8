<?php


function lang($phrase){

static $lg=array(

    // HOME PAGE
    "MESSAGE"=>"mar7aban",
    "ADMIN"=>"Administrator", 

);
return $lg[$phrase];

}

