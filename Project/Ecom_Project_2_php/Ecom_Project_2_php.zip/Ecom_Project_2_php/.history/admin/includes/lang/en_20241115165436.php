<?php


function lang($phrase){

static $


}

