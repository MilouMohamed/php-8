<?php


function lang($phrase){




}

