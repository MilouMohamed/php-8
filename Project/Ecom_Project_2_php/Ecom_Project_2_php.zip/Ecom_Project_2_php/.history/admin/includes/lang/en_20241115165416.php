<?php


function lang($){




}

