<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Footer ADMIN</title>
</head>
<body>



<h4>Footer Admin </h4> 
</body>
</html>
    