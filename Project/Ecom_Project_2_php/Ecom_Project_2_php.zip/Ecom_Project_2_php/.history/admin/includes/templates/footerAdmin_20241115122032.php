


<div class="footer">
    <h4>Footer Admin </h4> 
    <i class="fa fa-home fa-5    " size="lg"></i>
</div>

<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
<script src="./layout/js/backend.js"></script>
</body>
</html>
    