<?php 
include "init.php";
include("$tempheaderAdmin.php"); ?>

<h1>Page Admine ICI</h1>


<?php include("./includes/templates/footerAdmin.php"); ?>