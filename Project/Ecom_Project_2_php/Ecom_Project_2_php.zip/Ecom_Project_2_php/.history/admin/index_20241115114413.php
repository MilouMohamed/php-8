<?php 

include_once("./")
?>