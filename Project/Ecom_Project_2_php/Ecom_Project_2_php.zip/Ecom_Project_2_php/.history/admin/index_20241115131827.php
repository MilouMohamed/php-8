<?php 
include "init.php";
include("headerAdmin.php"); ?>

<h1>Page Admine ICI</h1>


<?php include($temp."footerAdmin.php"); ?>