<?php 
include "init.php";
include($temp."headerAdmin.php");
include "./includes/lang/en.php";
?>

<form action="<?php echo $_SERVER[""]?>" method="post" class="login-admin mx-auto mt-5" >
    <div class="container"> 
        <h2 class="text text-center text-black-50">Login Page</h2>
        <input  class="form-control text-black-50 mt-3" type="text" name="UserName" placeholder="Nom 1">
        <input  class="form-control text-black-50 mt-3" type="text" name="Password" placeholder="0000">
        <input  class="btn btn-primary w-100 mt-3 mb-3" type="submit" value="Connection">
        
    </div>
</form>

 

<?php include($temp."footerAdmin.php"); ?>