<?php


$cdn="Mysql:host=localhost;dbname=ecom_php_2";
$user="root";
$pass="";
$optionBD=array(
    PDO::MYSQL_ATTR_INIT_COMMAND
);


