<?php
include "init.php";

echo "Ecom Project n2 ";

echo "<br>";
echo "Test de Test ici ";
