<?php

require_once("connect.php");

$css="./layout/css/";
$js="./layout/js/";

$temp="./includes/templates/";
 
