<?php

/*
Categoreis Type  Add | Dellet | 
*/

$action= isset($_GET["do"] ? $_GET["do"] : "Manage";