<?php
session_start();

if (!isset($_SESSION["UserName"])) {
    header("location: index.php");
    exit;
} else {

    $titlePage = "Members";
    include "init.php";

    $action = isset($_GET["do"]) ? $_GET["do"] : "Manage";

    if ($action == "Manage") {
        echo "Page Manage";
    } elseif ($action == "Edit") {
        // echo "Page Edite ID = ". $_GET["UserId"] ; ?>

        <div class="container">
            <h1><?= lang("TITRE_MEMBERS") ?> </h1>
            <form class="form-group " action="" method="post"> 

                <div class="row g-3 align-items-center justify-content-center">
                    <div class="form-floating mb-3 col-lg-8 col-md-6 form-group-md">
                        <input type="text" class="form-control input-md" id="username" placeholder="Name">
                        <label for="username"><?= lang("NAME") ?></label>
                    </div>
                </div>

                <div class="row g-3 align-items-center justify-content-center">
                    <div class="form-floating mb-3 col-lg-8 col-md-6">
                        <input type="text" class="form-control" id="pass" placeholder="pass">
                        <label for="pass"><?= lang("PASSWORD") ?></label>
                    </div>
                </div>

                <div class="row g-3 align-items-center justify-content-center">
                    <div class="form-floating mb-3 col-lg-8 col-md-6">
                        <input type="text" class="form-control" id="email" placeholder="email@emaol.com">
                        <label for="email"><?= lang("EMAIL") ?></label>
                    </div>
                </div>

                <div class="row g-3 align-items-center justify-content-center">
                    <div class="form-floating mb-3 col-lg-8 col-md-6">
                        <input type="text" class="form-control" id="full" placeholder="Fullname">
                        <label for="full"><?= lang("FULLE_NAME") ?></label>
                    </div>
                </div>

                <div class="form-item">
                    <input class="btn btn-primary" type="submit" value="<?= lang("SAVE") ?>">
                </div>

            </form>


        </div>


        <?php
    }




    include($temp . "footerAdmin.php");
}

