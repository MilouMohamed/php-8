<?php

session_start();

if (!isset($_SESSION["UserName"])) {
    header("location: index.php");
    exit;
} else {
    
    $titlePage="Dashboard";
    include "init.php";

    // Start Dashboard $_SESSION['UserName'] $_SESSION['Id'].
?>

<div class="container">
    .das
<div class="col-md-3">

</div>

</div>
    
<?php

    // End Dashboard

    include($temp . "footerAdmin.php");
}

