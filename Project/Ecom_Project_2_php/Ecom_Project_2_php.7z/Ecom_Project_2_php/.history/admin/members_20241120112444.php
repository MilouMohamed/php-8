<?php
session_start();

if (!isset($_SESSION["UserName"])) {
    header("location: index.php");
    exit;
} else {

    $titlePage = "Members";
    include "init.php";

    $action = isset($_POST["do"]) ? $_POST["do"] : "Manage";

    if ($action == "Add") {
        echo "Page ADD";
    } elseif ($action == "Manage") {
        echo "Page Manage";
    }elseif ($action == "Edit") {
        echo "Page Manage";
    }




    include($temp . "footerAdmin.php");
}

