<?php 
include "init.php";
include($temp."headerAdmin.php");
include "./includes/lang/en.php";
?>

<form action="" method="post">



</form>



<h1>
    <?= lang("MESSAGE")." ".lang("ADMIN")  ?>
</h1>


<?php include($temp."footerAdmin.php"); ?>