<?php

session_start();

if (!isset($_SESSION["UserName"])) {
    header("location: index.php");
    exit;
} else {

    $titlePage = "Dashboard";
    include "init.php";

    // Start Dashboard $_SESSION['UserName'] $_SESSION['Id'].
    ?>

    <div class="container">
        <div class="dashbord-status"> 
            <div class="col-md-3 text-center">
                <h3>Total members</h3>

            </div>
        </div>

    </div>

    <?php

    // End Dashboard

    include($temp . "footerAdmin.php");
}

