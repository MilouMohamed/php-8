<?php 

session_start();

if(isset($_SESSION["UserName"])){ 
    include "init.php";

    echo "Bonjour ".$_SESSION["UserName"];
} else {  
    header("location: index.php"); 
    exit;
}

 
include($temp ."footerAdmin.php");
session_abort();
session_destroy();
