<?php 

session_start();

if(isset($_SESSION["UserName"])){

    echo "Bonjour ".$_SESSION["UserName"];
}
