<?php

/*
Categoreis Type  Add | Dellet | 
*/

$action= isset($_GET["do"]) ? $_GET["do"] : "Manage";

switch ($variable) {
    case 'value':
        # code...
        break;
    
    default:
        # code...
        break;
}