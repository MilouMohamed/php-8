<?php 

session_start();

if(isset($_SESSION["UserName"])){ 
    echo "Bonjour ".$_SESSION["UserName"];
} else {  
    header("location: index.php"); 
    // exit;
}

