<?php


$css="./layout/css/";
$js="./layout/js/"; 
$temp="./includes/templates/";
$lng="./includes/lang/";




require("connect.php");



if(!isset($noNavbar)) {

    include $temp."navbar.php";
}