<?php 
include "init.php";
include($temp."headerAdmin.php");
include "./includes/lang/en.php";
?>

<form action="" method="post" class="login-admin mx-auto" >
    <div class="container"> 
        <h2 class="text text-center">Login Page</h2>
        <input  class="form-control mt-3" type="text" name="UserName" placeholder="Nom 1">
        <input  class="form-control mt-3" type="text" name="Password" placeholder="0000">
        <input  class="form-control mt-3 mb-3" type="submit" value="Connection">
        
    </div>
</form>



<h1>
    <?= lang("MESSAGE")." ".lang("ADMIN")  ?>
</h1>


<?php include($temp."footerAdmin.php"); ?>