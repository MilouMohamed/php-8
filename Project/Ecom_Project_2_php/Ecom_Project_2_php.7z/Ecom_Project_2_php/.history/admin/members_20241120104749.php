<?php 
session_start();

if (!isset($_SESSION["UserName"])) {
    header("location: index.php");
    exit;
} else {
    
    $titlePage="Members";
    include "init.php";
    
$do=isset($_POST["do"]) ?  : ;




    include($temp . "footerAdmin.php");
}

