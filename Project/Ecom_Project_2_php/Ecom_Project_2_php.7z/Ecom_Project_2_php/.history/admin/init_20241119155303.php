<?php


$css="./layout/css/";
$js="./layout/js/"; 
$temp="./includes/templates/";
$lng="./includes/lang/";




  

include($temp . "headerAdmin.php");
include ($lng."ar.php");
// include ($lng."ar.php");

 
require("connect.php");

if(!isset($noNavbar)) {

    include $temp."navbar.php";
}