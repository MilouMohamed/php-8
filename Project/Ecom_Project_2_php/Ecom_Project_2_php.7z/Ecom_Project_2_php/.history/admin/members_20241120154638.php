<?php
session_start();

if (!isset($_SESSION["UserName"])) {
    header("location: index.php");
    exit;
} else {

    $titlePage = "Members";
    include "init.php";

    $action = isset($_GET["do"]) ? $_GET["do"] : "Manage";

    if ($action == "Manage") {
        echo "Page Manage";
    } elseif ($action == "Edit") {
        // echo "Page Edite ID = ". $_GET["UserId"] ;
        $userId = (isset($_GET["UserId"]) and intval($_GET["UserId"])) ? intval($_GET["UserId"]) : 0;


        if ($userId != 0) {
 
            $stim=$cnx->prepare("select *  from users where UserID=?");
             $stim->execute([$userId]);
             $item=$stim->fetch(PDO::FETCH_OBJ);
print_r()
             if($item->rowCount() > 0){


             }
             echo"<br> row Count";
echo $item->rowCount();
echo"<br>";


            ?>

            <div class="container">
                <h1><?= lang("TITRE_MEMBERS") ?> </h1>
                <form class="form-group " action="" method="post">

                    <div class="row g-3 align-items-center justify-content-center">
                        <div class="form-floating mb-3 col-lg-8 ">
                            <input type="text" class="form-control ps-4" id="username" placeholder="Name">
                            <label class="ps-4" for="username"><?= lang("NAME") ?></label>
                        </div>
                    </div>

                    <div class="row g-3 align-items-center justify-content-center">
                        <div class="form-floating mb-3 col-lg-8 ">
                            <input type="text" class="form-control ps-4" id="pass" placeholder="pass">
                            <label class="ps-4" for="pass"><?= lang("PASSWORD") ?></label>
                        </div>
                    </div>

                    <div class="row g-3 align-items-center justify-content-center">
                        <div class="form-floating mb-3 col-lg-8 ">
                            <input type="text" class="form-control ps-4" id="email" placeholder="email@emaol.com">
                            <label class="ps-4" for="email"><?= lang("EMAIL") ?></label>
                        </div>
                    </div>

                    <div class="row g-3 align-items-center justify-content-center">
                        <div class="form-floating mb-3 col-lg-8 ">
                            <input type="text" class="form-control ps-4" id="full" placeholder="Fullname">
                            <label class="ps-4" for="full"><?= lang("FULLE_NAME") ?></label>
                        </div>
                    </div>

                    <div class="row align-items-center justify-content-center">
                        <div class="col-lg-8  text-center">
                            <input class="btn btn-primary btn-lg w-100  " type="submit" value="<?= lang("SAVE") ?>">
                        </div>
                    </div>

                </form>


            </div> 
            <?php

        }else{?>
<div class="alert alert-danger">
    <h2><?= lang("NO_PROFILE_ID")?> </h2>
</div>
<?php }
    }




    include($temp . "footerAdmin.php");
}

