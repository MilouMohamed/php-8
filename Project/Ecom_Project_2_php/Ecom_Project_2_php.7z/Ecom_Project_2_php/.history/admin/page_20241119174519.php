<?php

/*
Categoreis Type  Add | Dellet | 
*/

$action= 