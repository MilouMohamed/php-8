<?php 
include("./includes/templates/headerAdmin.php");
?>

<h1>Page Admine ICI</h1>


<?php 
include("./includes/templates/footerAdmin.php");
?>
