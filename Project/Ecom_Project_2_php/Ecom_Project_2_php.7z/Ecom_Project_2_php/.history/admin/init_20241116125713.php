<?php

require("connect.php");

$css="./layout/css/";
$js="./layout/js/";

$temp="./includes/templates/";
 
