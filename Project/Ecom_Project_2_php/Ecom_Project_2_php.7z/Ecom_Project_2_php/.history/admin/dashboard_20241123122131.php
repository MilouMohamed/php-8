<?php

session_start();

if (!isset($_SESSION["UserName"])) {
    header("location: index.php");
    exit;
} else {
    
    $titlePage="Dashboard";
    include "init.php";

    // Start Dashboard $_SESSION['UserName'] $_SESSION['Id'].
?>

<div class="container">


</div>
    
<?php

    // End Dashboard

    include($temp . "footerAdmin.php");
}

