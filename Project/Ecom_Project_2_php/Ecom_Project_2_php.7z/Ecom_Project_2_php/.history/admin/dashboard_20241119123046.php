<?php 

session_start();
include "init.php";

if(isset($_SESSION["UserName"])){ 
    include $temp."heqder"

    echo "Bonjour ".$_SESSION["UserName"];
} else {  
    header("location: index.php"); 
    exit;
}

 
