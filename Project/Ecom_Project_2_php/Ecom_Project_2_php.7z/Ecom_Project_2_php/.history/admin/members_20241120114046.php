<?php
session_start();

if (!isset($_SESSION["UserName"])) {
    header("location: index.php");
    exit;
} else {

    $titlePage = "Members";
    include "init.php";

    $action = isset($_GET["do"]) ? $_GET["do"] : "Manage";

    if ($action == "Manage") {
        echo "Page Manage";
    } elseif ($action == "Edit") {
        // echo "Page Edite ID = ". $_GET["UserId"] ;?>
        
        
        <?php
         } 




    include($temp . "footerAdmin.php");
}

