<?php 

session_start();
include "init.php";

if(isset($_SESSION["UserName"])){ 

    echo "Bonjour ".$_SESSION["UserName"];
} else {  
    header("location: index.php"); 
    exit;
}

 
include($temp ."footerAdmin.php");
// session_destroy();
// session_abort();
