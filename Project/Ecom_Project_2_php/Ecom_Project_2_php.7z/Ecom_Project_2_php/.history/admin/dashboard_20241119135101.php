<?php

session_start();

if (!isset($_SESSION["UserName"])) {
    header("location: index.php");
    exit;
} else {

    include "init.php";
    echo "Bonjour User Name=  " . $_SESSION["UserName"];


    include($temp . "footerAdmin.php");
}

