<?php
session_start();

if (!isset($_SESSION["UserName"])) {
    header("location: index.php");
    exit;
} else {

    $titlePage = "Members";
    include "init.php";

    $action = isset($_GET["do"]) ? $_GET["do"] : "Manage";

    if ($action == "Manage") {
        echo "Page Manage";
    } elseif ($action == "Edit") {
        // echo "Page Edite ID = ". $_GET["UserId"] ; ?>

        <div class="container">
            <h1><?= lang("TITRE_MEMBERS") ?> </h1>
            <form class="form-group " action="" method="post">

                <div class="form-item">
                    <label for="username"><?= lang("NAME") ?></label>
                    <input type="text" name="username" id="username">
                </div>

                <div class="form-item">
                    <label for="pass"><?= lang("PASSWORD") ?></label>
                    <input type="text" name="pass" id="pass">
                </div>

                <div class="form-item">
                    <label for="email"><?= lang("EMAIL") ?></label>
                    <input type="text" name="email" id="email">
                </div>


                <div class="form-item">
                    <label for="full"><?= lang("FULLE_NAME") ?></label>
                    <input type="text" name="full" id="full">
                </div>


                <div class="row g-3 align-items-center justify-content-center">
                    <div class="form-floating mb-3 col-lg-8 col-md-6">
                        <input type="email" class="form-control" id="floatingInput" placeholder="name@example.com">
                        <label for="floatingInput"><?= lang("FULLE_NAME") ?></label>
                    </div> 
                </div>

                <div class="form-item">
                    <input class="btn btn-primary" type="submit" value="<?= lang("SAVE") ?>">
                </div>

            </form>


        </div>


        <?php
    }




    include($temp . "footerAdmin.php");
}

