<?php

require("connect.php");

$css="./layout/css/";
$js="./layout/js/"; 
$temp="./includes/templates/";
$lng="./includes/lang/";
 






if(!isset($noNavbar)) {

    include $temp."navbar.php";
}