<?php
session_start();

if (!isset($_SESSION["UserName"])) {
    header("location: index.php");
    exit;
} else {

    $titlePage = "Members";
    include "init.php";

    $action = isset($_GET["do"]) ? $_GET["do"] : "Manage";

    if ($action == "Manage") {
        echo "Page Manage";
    } elseif ($action == "Edit") {
        // echo "Page Edite ID = ". $_GET["UserId"] ;?>
        
<div class="container">
<h1><?= lang("TITRE_MEMBERS")?> </h1>
<form class="form-group " action="" method="post">
    
<div class="form-item">
    <label for="username"><?= lang("NAME") ?></label>
    <input type="text" name="username" id="username">
</div>

<div class="form-item">
    <label for="pass"><?= lang("PASSWORD") ?></label>
    <input type="text" name="pass" id="pass">
</div>

<div class="form-item">
    <label for="email"><?= lang("EMAIL") ?></label>
    <input type="text" name="email" id="email">
</div>
 

<div class="form-item">
    <label for="full"><?= lang("FULLE_NAME") ?></label>
    <input type="text" name="full" id="full">
</div>

<div class="form-item">
    
</div>

</form>


</div>

        
        <?php
         } 




    include($temp . "footerAdmin.php");
}

