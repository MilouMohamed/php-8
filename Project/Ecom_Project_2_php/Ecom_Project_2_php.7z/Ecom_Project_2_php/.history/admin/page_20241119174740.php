<?php

/*
Categoreis Type  Add | Dellet | 
*/

$action= isset($_GET["do"]) ? $_GET["do"] : "MANAGE";

switch ($action) {
    case 'MANAGE':
        {echo "<>"; 
            break;
        }
    
        case 'ADD':
            {echo "Is Page Add"; 
                break;
            }
        
    default:
    echo "Is Error No page ";  
        break;
}