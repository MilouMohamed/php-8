<?php 

session_start();

if(isset($_SESSION["UserName"])){ 
    echo "Bonjour ".$_SESSION["UserName"];
} else {
    echo "Vous n aves Pas le Droit D accide a cette Page<br>";
}

